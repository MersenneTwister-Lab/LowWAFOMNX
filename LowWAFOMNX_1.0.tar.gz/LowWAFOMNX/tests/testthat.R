library(testthat)
test_check("LowWAFOMNX")
